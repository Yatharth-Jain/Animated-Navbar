import Navbar from "../src/components/Navbar/Navbar";

export default function about() {
  return (
    <>
      <Navbar/>
      <div className="firstdiv aboutdiv">about</div>
    </>
  )
}
