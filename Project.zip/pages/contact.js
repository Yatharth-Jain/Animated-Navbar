import Navbar from "../src/components/Navbar/Navbar";

export default function contact() {
  return (
    <>
      <Navbar/>
      <div className="firstdiv contactdiv">contact</div>
    </>
  )
}
